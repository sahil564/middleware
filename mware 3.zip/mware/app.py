import requests
import json
center_id="a9f1eac2-9755-45c7-9cbd-c3f55383d760"
# guest_search_url = "https://api.zenoti.com/v1/guests/search?phone={}".format(9376320564)
header = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': "apikey f82354eaf23c46e8a2425783d1c08126efb1ce201b204502a3f462031115d113"
            }

# response = requests.get(guest_search_url, headers=header).json()
# print(response)
# guest=response["guests"]
# print(guest[0]["id"])

# import requests

# url = "https://api.zenoti.com/v1/opportunities/opportunity_id={}".format(6623C732-B184-4FD1-984D-E45B0AF8DEAE)

# headers = {
#     "accept": "application/json",
#     "Authorization": "apikey <your api key>"
# }

# response = requests.get(url, headers=header)

# print(response.text)

url = "https://api.zenoti.com/v1/guests"


create_guest_body = json.dumps({"center_id":center_id,
                "personal_info":{
                "mobile_phone":{
                    "phone_code":+91,
                    "number":"9900112233"
                    },
                "first_name":"pawan",
                "last_name":"kumar",
                "email":"pawan123123@gmail.com",
                "gender":"male",
            
                }
                })



response = requests.post(url, headers=header,data = create_guest_body)

print(response.text)
print(response)

print("created guest",guest_create_response)
print(type(guest_create_response.text))
guestid=json.loads(guest_create_response.text)
print(type(guestid))
guest_id=list(guestid.values())[0]

print("this is guest id",guest_id)
#Create opportunity
opportunity_title = first_name+last_name
create_opportunity_body = json.dumps({
"center_id": center_id,
"opportunity_title": opportunity_title,
"guest_id": guest_id,
"created_by_id": guest_id,
"followup_date": "2023-08-17T12:22:06"
})
response = requests.post(opp_url, headers=header, data = create_opportunity_body)
print(response.text)
print(response)