from django.contrib import admin
from core.models import *
# Register your models here.
admin.site.register(Lead),
admin.site.register(Center_master),
admin.site.register(Category_service_master)
admin.site.register(Source_master)
