from django.urls import path
from core.views import *
from core.webhook import *
from core.views1 import *

urlpatterns = [
    path("",form,name="form"),
    path("register",register,name="register"),
    path("new/",new,name="new"),
    path("webhook/",fb_webhook,name="webhook"),
    path("hello/",hello,name="hello"),
    path("ivr/",book,name="book")
]