from django.db import models

# Create your models here.



class Lead(models.Model):
    first_name=models.CharField(max_length=200)
    last_name=models.CharField("enter last name",max_length=200)
    gender=models.CharField("enter gender name",max_length=200)
    email=models.EmailField("enter email",max_length=200)
    number=models.CharField("enter first number",max_length=200)
    category=models.CharField("enter first category",max_length=200)
    service=models.CharField("enter first service",max_length=200)
    city=models.CharField("enter first city",max_length=200)
    center=models.CharField("enter first center",max_length=200)
    date = models.DateField(auto_now_add=True, null=True)
    UTM=models.CharField(max_length=200,default=True)
    source=models.CharField(max_length=200,default=True)


    def __str__(self):
        return f'{self.first_name} {self.last_name} {self.number}'
    


class Center_master(models.Model):
    center_name=models.CharField(max_length=200,default="Please Enter Center Name")
    center_code=models.CharField(max_length=200,default="Please Enter Center Code")
    Region_name=models.CharField(max_length=200,default="Please Enter Region Name")
    Area_name=models.CharField(max_length=200,default="Please Enter Area Name")
    center_id=models.CharField(max_length=200,default="Please Enter Center ID")

    def __str__(self):
        return self.center_name
    
# class Source_master(models.Model):




class Category_service_master(models.Model):
    service_id=models.CharField(max_length=100)
    category=models.CharField(max_length=100)
    service=models.CharField(max_length=100)


    def __str__(self):
        return f'{self.service_id} {self.category} {self.service}'

class Source_master(models.Model):
    Source_id=models.CharField(max_length=100)
    Source_code=models.CharField(max_length=100)
    Source_name=models.CharField(max_length=100)

    def __str__(self):
        return f'{self.Source_name}' 