from rest_framework.decorators import api_view
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.authentication import SessionAuthentication, BasicAuthentication,TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import permission_classes,authentication_classes
import time
from threading import Thread
from core.models import Lead ,Center_master,Source_master
# import datetime
from datetime import date
import requests
import json

resp="true"




opp_url = "https://api.zenoti.com/v1/opportunities"
guest_endpoint_url = "https://api.zenoti.com/v1/guests"
# Create your views here.
import urllib3
urllib3.disable_warnings()

header = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': "apikey f82354eaf23c46e8a2425783d1c08126efb1ce201b204502a3f462031115d113"
            }



CZ_login_url = "https://vlcc.c-zentrixcloud.com/api/login"

payload = 'username=Tanya&password=Test%40123'
headers = {
  'Content-Type': 'application/x-www-form-urlencoded'
}



CZ_Token=[]



def disp():
    while True:
        response = requests.request("POST", CZ_login_url, headers=headers, data=payload ,verify=False)
        print(response.json()["token"])
        CZ_Token.append(response.json()["token"])

        time.sleep(6500)


t=Thread(target=disp)
t.start()













cz_url = "https://vlcc.c-zentrixcloud.com/api/bulklead"








@api_view(["POST"])
@authentication_classes([SessionAuthentication, BasicAuthentication,TokenAuthentication])
@permission_classes([IsAuthenticated])
def book(request):
    data=request.data
    print(data)
    print(data["first_name"])
    first_name=data['first_name']
    last_name=data["last_name"]
    gender=data["gender"]
    email=data['email']
    number=data['number']
    category=data['category']
    service=data['service']
    country_code="+91"
    city=data['city']
    center=data['center_code']
    utm=data['offer_utm_link']
    source=data["source"]
    center_id=list(Center_master.objects.filter(center_code=center))[-1]
    print(center_id.center_id)
    center_id=center_id.center_id
    print(source)
    source_id=list(Source_master.objects.filter(Source_name=source.upper()))[-1]
    source_id=source_id.Source_id
    print(source_id)
    print(first_name,last_name,gender,email,number,category,service,city,center)
    user=Lead(first_name=first_name,last_name=last_name,gender=gender,email=email,number=number,category=category,service=service,city=city,center=center,UTM=utm,source=source)
    today = date.today()
    today = str(today)
    sortbydate=list(Lead.objects.filter(number=number,date=today))
    if len(sortbydate)>=1:
        for i in sortbydate:
            if i.service==service:
                print("category already presant")
                a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                return Response(a,status=200)
            #Search or create guest
            user.save()
            guest_search_url="https://api.zenoti.com/v1/guests/search?phone={}&expand=preferences&expand=tags".format(number)
            guest_search_response = requests.get(guest_search_url, headers=header).json()
            if(guest_search_response["page_Info"]["total"] > 0):
                guest_list = guest_search_response["guests"]
                if(len(guest_list) > 1):
                    print('List of guests')
                    [print('{0}. {1} - {2} {3}'.format(str(j+1), i["personal_info"]["user_name"], i["personal_info"]["first_name"], i["personal_info"]["last_name"])) for j,i in enumerate(guest_list)]
                    guest_id = guest_list[int("1")-1]["id"]
                    create_opportunity_body = json.dumps({"center_id": center_id,"opportunity_title":  first_name+last_name,"guest_id": guest_id,"created_by_id": guest_id,"followup_date": today,"lead_source":{"id":source_id,},"optional_field_1":utm,"optional_field_2":category,"type":service,})
                    response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                    print(response.text)
                    guest_search_response=guest_list[int("1")-1]
                    if guest_search_response['guests'][0]["tags"]==["DND"]:
                        print("DND applied on user on number",number)
                        print("")
                        a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                        return Response(a,status=200)
                    else:
                        payload = json.dumps([{"camp_name":"Test_Zenoti", "mobile": number,"name": first_name+last_name,"City":city,"UniqueID":"Ivdps1930p","CustUniqueld":response.json()["opportunity_id"],"Guest_id":guest_id},])
                        cz_headers = {'x-access-token':CZ_Token[-1],'Content-Type': 'application/json','Cookie': 'adminuiSessCZ=147a4374b4affc43e7be7847d88e8447'}
                        response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                        print(response.text)
                        print("succesfully call sent to dialer  multiple guest existed 1")
                        a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                        return Response(a,status=200)
                
                else:
                    guest_id = guest_list[0]["id"]
                    #create_opportunity_body = json.dumps({"center_id": center_id,"opportunity_title": first_name+last_name,"guest_id": guest_id,"created_by_id": guest_id,"followup_date": today,"type":service,"optional_field_1":utm,"optional_field_2":category})
                    create_opportunity_body = json.dumps({"center_id": center_id,"opportunity_title": first_name+last_name,"guest_id": guest_id,"created_by_id": guest_id,"followup_date": today,"lead_source":{"id":source_id,},"type":service,"optional_field_1":utm,"optional_field_2":category,})
                    response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                    print(response.text)
                    if guest_search_response['guests'][0]["tags"]==["DND"]:
                        print("DND applied on user on number",number)
                        print("")
                        a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                        return Response(a,status=200)
                    else:
                        payload = json.dumps([{"camp_name":"Test_Zenoti", "mobile": number,"name": first_name+last_name,"City":city,"UniqueID":"Ivdps1930p","CustUniqueld":response.json()["opportunity_id"],"Guest_id":guest_id},])
                        cz_headers = {'x-access-token':CZ_Token[-1],'Content-Type': 'application/json','Cookie': 'adminuiSessCZ=147a4374b4affc43e7be7847d88e8447'}
                        response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                        print(response.text)
                        print("succesfully call sent to dialer  multiple guest existed 1")
                        a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                        return Response(a,status=200)

    else:
        user.save()
        guest_search_url="https://api.zenoti.com/v1/guests/search?phone={}&expand=preferences&expand=tags".format(number)
        guest_search_response = requests.get(guest_search_url, headers=header).json()
        if(guest_search_response["page_Info"]["total"] > 0):
            guest_list = guest_search_response["guests"]
            if(len(guest_list) > 1):
                print('List of guests')
                [print('{0}. {1} - {2} {3}'.format(str(j+1), i["personal_info"]["user_name"], i["personal_info"]["first_name"], i["personal_info"]["last_name"])) for j,i in enumerate(guest_list)]
                guest_id = guest_list[int(1)-1]["id"]
                #create_opportunity_body = json.dumps({"center_id": center_id,"opportunity_title""guest_id": guest_id,"created_by_id": guest_id,"followup_date": today,"type":service,"optional_field_1":utm,"optional_field_2":category,})
                create_opportunity_body = json.dumps({"center_id": center_id,"opportunity_title": first_name+last_name,"guest_id": guest_id,"created_by_id": guest_id,"followup_date": today,"lead_source":{"id":source_id,},"type":service,"optional_field_1":utm,"optional_field_2":category,})
                response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                print(response.text)
                guest_search_response=guest_list[int("1")-1]
                if guest_search_response['guests'][0]["tags"]==["DND"]:
                    print("DND applied on user on number",number)
                    print("")
                    a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                    return Response(a,status=200)
                else:
                    payload = json.dumps([{"camp_name":"Test_Zenoti", "mobile": number,"name": first_name+last_name,"City":city,"UniqueID":"Ivdps1930p","CustUniqueld":response.json()["opportunity_id"],"Guest_id":guest_id},])
                    cz_headers = {'x-access-token':CZ_Token[-1],'Content-Type': 'application/json','Cookie': 'adminuiSessCZ=147a4374b4affc43e7be7847d88e8447'}
                    response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                    print(response.text)
                    print("succesfully call sent to dialer  multiple guest existed 1")
                    a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                    return Response(a,status=200)
                
            else:
                guest_id = guest_list[0]["id"]
                #create_opportunity_body = json.dumps({"center_id": center_id,"opportunity_title": first_name+last_name,"guest_id": guest_id,"created_by_id": guest_id,"followup_date": today,"type":service,"optional_field_1":utm,"optional_field_2":category})
                create_opportunity_body = json.dumps({"center_id": center_id,"opportunity_title": first_name+last_name,"guest_id": guest_id,"created_by_id": guest_id,"followup_date": today,"lead_source":{"id":source_id,},"type":service,"optional_field_1":utm,"optional_field_2":category,})
                response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                print(response.text)
                if guest_search_response['guests'][0]["tags"]==["DND"]:
                    print("DND applied on user on number",number)
                    print("")
                    a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                    return Response(a,status=200)
                else:
                    payload = json.dumps([{"camp_name":"Test_Zenoti", "mobile": number,"name": first_name+last_name,"City":city,"UniqueID":"Ivdps1930p","CustUniqueld":response.json()["opportunity_id"],"Guest_id":guest_id},])
                    cz_headers = {'x-access-token':CZ_Token[-1],'Content-Type': 'application/json','Cookie': 'adminuiSessCZ=147a4374b4affc43e7be7847d88e8447'}
                    response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                    print(response.text)
                    print("succesfully call sent to dialer  multiple guest existed 1")
                    a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
                    return Response(a,status=200)
        else:
            print("Guest not found.\n\nEnter details to create the guest.")
            def create_guest(error):
                if(error):
                    print("\nThere was an error in guest object. Please retry.\n")
                create_guest_body = json.dumps({"center_id":center_id,"personal_info":{"mobile_phone":{"phone_code":country_code,"number":number,},"first_name":first_name,"last_name":first_name,"email":email,"gender":gender}})
                guest_create_responsenew = requests.post(guest_endpoint_url, headers=header, data = create_guest_body)
                print("guest",guest_create_responsenew.text)
                print(guest_create_responsenew)
                if(guest_create_responsenew.ok):
                    create_opportunity_body = json.dumps({"center_id": center_id,"opportunity_title": first_name+last_name,"guest_id": guest_create_responsenew.json()["id"],"created_by_id": guest_create_responsenew.json()["id"],"followup_date": today,"lead_source":{"id":source_id,},"type":service,"optional_field_1":utm,"optional_field_2":category,})
                    
                    response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                    print(response.text)

                    payload = json.dumps([{"camp_name": "Test_Zenoti","mobile": number,"name": first_name+last_name,"Guest_id":guest_create_responsenew.json()["id"],"CustUniqueld":response.json()["opportunity_id"],},])
                    cz_headers = {'x-access-token':CZ_Token[-1],'Content-Type': 'application/json','Cookie': 'adminuiSessCZ=147a4374b4affc43e7be7847d88e8447'}
                    response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                    print(response.text)
             
                else:
                    create_guest(True)
                   
            guest_id = create_guest(False)
            a={"success":resp,"phone":number,"message":"lead Created Succesfully","status":200}
            return Response(a,status=200)




