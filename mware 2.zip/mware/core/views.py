from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect
from django.contrib import messages
from core.models import Lead 
# import datetime
from datetime import date
from datetime import datetime
# 1. Import the csrf_exempt decorator
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
import urllib3
urllib3.disable_warnings()


import requests
import json
cz_url = "https://vlcc.c-zentrixcloud.com/api/bulklead"

cz_headers = {
  'x-access-token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxMTcsInJvbGVfaWQiOjEsInVzZXJfbmFtZSI6InRhbnlhIiwiaWF0IjoxNjkzMzE2MTk3LCJleHAiOjE2OTMzMjMzOTd9.7TXyMl5_cCkg5HE4KcGCbo-jC6ceeGb-WWDzpqiiK34',
  'Content-Type': 'application/json',
  'Cookie': 'adminuiSessCZ=147a4374b4affc43e7be7847d88e8447'
}




import json
import requests
zenoti_api="api.zenoti.com/"
center_id="a9f1eac2-9755-45c7-9cbd-c3f55383d760"
guest_endpoint_url = "https://api.zenoti.com/v1/guests"
opp_url = "https://api.zenoti.com/v1/opportunities"

header = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': "apikey f82354eaf23c46e8a2425783d1c08126efb1ce201b204502a3f462031115d113"
            }



def form(request):
    # ab=str(current_time)
    # a=ab[0:10]
    # l=a.replace("-", "/")
    # l=l.replace("/0", "/")
    # print("cureent time",l)
    # q=list(Lead.objects.filter(number="08905086536"))
    # print(q)
    # q=q[-1]
    # print(q.date)
    # print(q.service)
    # d=str(q.date)


    # today = date.today()
    # today = str(today)
    # today=today.replace("-0", "-")
    # sortbydate=list(Lead.objects.filter(number="08905086536",date="2023-08-17"))
    # print("bydateshort",sortbydate)
    # print("Today's date:", today)

    # str_d1 = '2021-10-20'
    # str_d2 = '2021-10-20'
    # str_d1=str_d1.replace("-0","-")
    # print(str_d1)
    # # convert string to date object
    # d1 = datetime.strptime(str_d1, "%Y-%m-%d")
    # d2 = datetime.strptime(today, "%Y-%m-%d")
    # # difference between dates in timedelta
    # delta = d2 - d1
    # print(f'Difference is {delta.days} days')


    # d1 = datetime.strptime(d, "%Y/%m/%d")
    # d2 = datetime.strptime(l, "%Y/%m/%d")
    # print(d1,d2)
    # delta = d2 - d1
    # print(f'Difference is {delta.days} days')



    # Printing value of now.
    
    # for i in q:
    #     print(i.date)


    return render(request,"form.html")

# @csrf_exempt
def register(request):
    print("post method called")
    if request.method=='POST':
        print("inside post method called")
        first_name=request.POST['first_name']

        last_name=request.POST["last_name"]
        gender=request.POST["gender"]
        email=request.POST['email']
        number=request.POST['number']
        category=request.POST['category']
        service=request.POST['service']
        country_code="+91"
        city=request.POST['city']
        center=request.POST["center"]

        print(first_name,last_name,gender,email,number,category,service,city,center)
        user=Lead(first_name=first_name,last_name=last_name,gender=gender,email=email,number=number,category=category,service=service,city=city,center=center)
        
        today = date.today()
        today = str(today)
        sortbydate=list(Lead.objects.filter(number=number,date=today))
        if len(sortbydate)>=1:
            for i in sortbydate:
                if i.service==service:
                    return render(request,"index.html",{"text":"you already register please try after 24 hours"})
            user.save()
            #Search or create guest
            guest_search_url="https://api.zenoti.com/v1/guests/search?phone={}&expand=preferences&expand=tags".format(number)
            guest_search_response = requests.get(guest_search_url, headers=header).json()

            if(guest_search_response["page_Info"]["total"] > 0):
                guest_list = guest_search_response["guests"]
                if(len(guest_list) > 1):
                    print('List of guests')
                    [print('{0}. {1} - {2} {3}'.format(str(j+1), i["personal_info"]["user_name"], i["personal_info"]["first_name"], i["personal_info"]["last_name"])) for j,i in enumerate(guest_list)]
                    guest_id = guest_list[int("1")-1]["id"]
                    
                    create_opportunity_body = json.dumps({
                        "center_id": center_id,
                        "opportunity_title": first_name+last_name,
                        "guest_id": guest_id,
                        "created_by_id": guest_id,
                        "followup_date": today,                
                        "type":service,
                        "optional_field_1":"UTM/googe/form",
                        "optional_field_2":category,
                        })
                    response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                    print(response.text)
                    print(response)
                    # guest=guest_search_response["guests"]
                    if guest_search_response['guests'][0]["tags"]==["DND"]:
                        print("DND applied on user on number",number)
                        print("")
                    else:
                        payload = json.dumps([{"camp_name":"Test_Zenoti", "mobile": number,"name": first_name+last_name,"City":city,"UniqueID":"Ivdps1930p","CustUniqueld":response.json()["opportunity_id"],"Guest_id":guest_id},])
                        response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                        print(response.text)
                        print("succesfully call sent to dialer  multiple guest existed 1")




                else:
                    guest_id = guest_list[0]["id"]
                    create_opportunity_body = json.dumps({
                        "center_id": center_id,
                        "opportunity_title": first_name+last_name,
                        "guest_id": guest_id,
                        "created_by_id": guest_id,
                        "followup_date": today,
                        "type":service,
                        "optional_field_1":"UTM/googe/form",
                        "optional_field_2":category,
                        })
                    response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                    print(response.text)
                    print(response)
                    print("guest is already created only one id guest has")
                    # guest=guest_search_response["guests"]
                    # print(guest[0]["tags"][0])
                    print(guest_search_response)
                    if guest_search_response['guests'][0]["tags"]==["DND"]:
                        print("DND applied on user phone number",number)
                        print("single user DND called",)
                    else:
                        payload = json.dumps([{"camp_name": "Test_Zenoti", "mobile": number,"name": first_name+last_name,"pin":"301001","city":"Alwar","uniqueID":"Ivdps1930p","CustUniqueld":response.json()["opportunity_id"],"Guest_id":guest_id},])
                        response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                    print("Guest found.\n")




        else:
            #NO user entry found
            user.save()
            #Search or create guest
            guest_search_url="https://api.zenoti.com/v1/guests/search?phone={}&expand=preferences&expand=tags".format(number)
            guest_search_response = requests.get(guest_search_url, headers=header).json()
            if(guest_search_response["page_Info"]["total"] > 0):
                guest_list = guest_search_response["guests"]
                if(len(guest_list) > 1):
                    print('List of guests')
                    [print('{0}. {1} - {2} {3}'.format(str(j+1), i["personal_info"]["user_name"], i["personal_info"]["first_name"], i["personal_info"]["last_name"])) for j,i in enumerate(guest_list)]
                    guest_id = guest_list[int(1)-1]["id"]
                    create_opportunity_body = json.dumps({
                        "center_id": center_id,
                        "opportunity_title": first_name+last_name,
                        "guest_id": guest_id,
                        "created_by_id": guest_id,
                        "followup_date": today,
                        "type":service,
                        "optional_field_1":"UTM/googe/form",
                        "optional_field_2":category,
                        })
                    response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                    print(response.text)
                    print(response)
                    # guest=guest_search_response["guests"]
                    print(guest_search_response["guests"])
                    if guest_search_response['guests'][0]["tags"]==["DND"]:
                        print("else mulptiple user")
                        print("DND applied on user phone number",number)

                    else:
                        payload = json.dumps([{"camp_name": "Test_Zenoti", "mobile": number,"name": first_name+last_name,"City":city,"UniqueID":category,"CustUniqueld":response.json()["opportunity_id"],"Guest_id":guest_id},])
                        response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                        print(response.text)
                        print("else mulptiple user")
                        print("in new user successfully sent request to dialer")
                else:
                    guest_id = guest_list[0]["id"]
                    create_opportunity_body = json.dumps({
                        "center_id": center_id,
                        "opportunity_title": first_name+last_name,
                        "guest_id": guest_id,
                        "created_by_id": guest_id,
                        "followup_date": today,
                        "type":service,
                        "optional_field_1":"UTM/googe/form",
                        "optional_field_2":category,
                        })
                    response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                    print(response.text)
                    print(response)
                    print("Guest found.\n")
                    # guest=guest_search_response["guests"]
                    print(guest_search_response['guests'][0]["tags"]==["DND"])
                    if guest_search_response['guests'][0]["tags"]==["DND"]:
                        print("DND applied on user phone number",number)
                        print("else phone user single")
                    
                    else:
                        payload = json.dumps([{"camp_name": "Test_Zenoti", "mobile": number,"name": first_name+last_name,"City":city,"UniqueID":category,"CustUniqueld":response.json()["opportunity_id"],"Guest_id":guest_id},])
                        response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                        print(response.text)
                        print("send to dialer user single guest new created id")
                        print("else phone user single")
        


            else:
                print("Guest not found.\n\nEnter details to create the guest.")
                def create_guest(error):
                    if(error):
                        print("\nThere was an error in guest object. Please retry.\n")
                    create_guest_body = json.dumps({
                        "center_id":center_id,
                        "personal_info":{
                            "mobile_phone":{
                                "phone_code":country_code,
                                "number":number,
                                },
                        "first_name":first_name,
                        "last_name":first_name,
                        "email":email,
                        "gender":gender
                        }})
                    guest_create_responsenew = requests.post(guest_endpoint_url, headers=header, data = create_guest_body)
                    print("guest",guest_create_responsenew.text)
                    print(guest_create_responsenew)

                    if(guest_create_responsenew.ok):
                        print("Guest created successfully!\n")
                        guest_id=guest_create_responsenew.json()["id"]
                        create_opportunity_body = json.dumps({
                        "center_id": center_id,
                        "opportunity_title": first_name+last_name,
                        "guest_id": guest_id,
                        "created_by_id": guest_id,
                        "followup_date": today,
                        "type":service,
                        "optional_field_1":"UTM/googe/form",
                        "optional_field_2":category,
                        })
                        response = requests.post(opp_url, headers=header, data = create_opportunity_body)
                        print(response.text)
                        print(response)
                        payload = json.dumps([{"camp_name": "Test_Zenoti","mobile": number,"name": first_name+last_name,"Guest_id":guest_id,"CustUniqueld":response.json()["opportunity_id"],},])
                        response = requests.request("POST", cz_url, headers=cz_headers, data=payload ,verify=False)
                        print(response.text)
                        print("success fully created on new user with no multimple guest")
                        print("newly user register")



                    else:
                        create_guest(True)
                guest_id = create_guest(False)
        
        
        

        
        
        return render(request,'index.html',{"text":'succesfully created opportunity of already exited user team will contact you in within 24 hours'})

    else:
        print("this is not post request")
        return render(request,"index.html")
    





def new(request):
    str_d1 = '2021-10-20'
    str_d2 = '2021-10-20'

    # convert string to date object
    d1 = datetime.strptime(str_d1, "%Y-%m-%d")
    d2 = datetime.strptime(str_d2, "%Y-%m-%d")
    # difference between dates in timedelta
    delta = d2 - d1
    print(f'Difference is {delta.days} days')
    


    return render(request,"index.html")


